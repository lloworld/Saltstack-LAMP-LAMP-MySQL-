<?php

/** @generate-function-entries */

final class Attribute
{
    public function __construct(int $flags = Attribute::TARGET_ALL) {}
}
